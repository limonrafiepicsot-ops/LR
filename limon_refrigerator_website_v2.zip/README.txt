Limon Refrigerator Website v2
Open index.html or publish the folder with GitHub Pages.
Backup/Restore uses a JSON file downloaded to your device.