package com.limon.refrigerator;
import android.app.Activity; import android.os.Bundle; import android.content.Intent; import android.net.Uri; import android.webkit.WebSettings; import android.webkit.WebView; import android.webkit.WebViewClient;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); w.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView view,String url){ if(url.startsWith("https://wa.me/")||url.startsWith("whatsapp:")){ try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.whatsapp.com/")));} return true;} return false; }}); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); setContentView(w); w.loadUrl("file:///android_asset/index.html");}
}
